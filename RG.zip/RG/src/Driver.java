import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.*;
import java.util.Map;
import java.util.Scanner;


public class Driver {

	public static void main(String[] args) throws IOException {
		String file = "C:\\Users\\ckobel\\workspace\\RG\\raw_resume_text.txt";
		FileReader fr = new FileReader(file);
		Scanner scanner = new Scanner(fr);
		String word;
		int count;
		HashMap<String, Integer> wordCountData = new HashMap<String, Integer>();
		
		
		while(scanner.hasNext()){
			word = scanner.next();
			if(word.length() < 3){continue;}
			word = word.toLowerCase();
			word = word.replaceAll("[^a-zA-Z0-9\\s]", "");
			
			if(wordCountData.containsKey(word)){
				count = wordCountData.get(word) + 1;
			}
			else{
				count = 1;
			}
			
			wordCountData.put(word, count);
		}
		
		HashMap<String, Integer> sortedHashMap = sortByValues(wordCountData);		
		
		
		 
		        System.out.println("-----------------------------------------------");
		        System.out.println("    Occurrences    Word");

		        for(String currWord : sortedHashMap.keySet( ))
		        {
		            System.out.printf("%15d    %s\n", wordCountData.get(currWord), currWord);
		            System.out.println();
		        }

		        System.out.println("-----------------------------------------------");	
		
	}
	
	 private static HashMap sortByValues(HashMap map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o2, Object o1) {
	               return ((Comparable) ((Map.Entry) (o1)).getValue())
	                  .compareTo(((Map.Entry) (o2)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap sortedHashMap = new LinkedHashMap();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey(), entry.getValue());
	       } 
	       return sortedHashMap;
	  }

	


}
